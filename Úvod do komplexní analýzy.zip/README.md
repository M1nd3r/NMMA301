# NMMA301 - Úvod do komplexní analýzy

Struktura repozitáře:

► .zip file obsahující zdrojový kód

► zkompilované PDF

► složka "zdroj" obsahující rozbalený source code (pro snadné porovnávání změn a GitBlame)

-------------------------------------------------------------

Pokud do repozitáře nahrávate nějaké změny, ujistěte se, že nahrávate všechny zmíněné části ve stejné verzi.
